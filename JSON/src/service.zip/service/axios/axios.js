import axios from "axios";

const licvifyService = axios.create({

    baseURL: "https://qa.licvify.com/remote/router/",
    timeout: 60000,
    headers: {
        "Content-type": "application/json"
    }
});

// request interceptor for adding token
licvifyService.interceptors.request.use((config) => {
    // add token to request headers
    config.headers.Authorization = `Bearer ${localStorage.getItem('token')}`;
    return config;
});

export default licvifyService;