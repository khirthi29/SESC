import licvifyService from "../axios/axios";

class UserService {

    getUserList(data) {
        return Promise.resolve(licvifyService.post('getuserlistli', data));
    }

    setUserStatus(data) {
        return Promise.resolve(licvifyService.post('setuserstatusli', data));
    }

    createUser(data) {
        return Promise.resolve(licvifyService.post('createuserli', data));
    }

    updateUser(data) {
        return Promise.resolve(licvifyService.post('edituserli', data));
    }
    
}

export default UserService;