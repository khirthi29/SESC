import licvifyService from "../axios/axios";

class SubjectService {

    addSubject(data) {
        return Promise.resolve(licvifyService.post('addsubli', data));
    }

    getSubject(data) {
        return Promise.resolve(licvifyService.post('getsubli', data));
    }
    
    modifySubject(data) {
        return Promise.resolve(licvifyService.post('modifysubli', data));
    }

    getTopic(data) {
        return Promise.resolve(licvifyService.post('gettopicli', data));
    }

    getContent(data) {
        return Promise.resolve(licvifyService.post('gettextli', data));
    }

    generateAccessKey(data) {
        return Promise.resolve(licvifyService.post('setapikeyli', data));
    }

}

export default SubjectService;