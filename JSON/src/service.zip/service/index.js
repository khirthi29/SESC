import AuthService from "./auth/auth";
import SubjectService from "./subject/subject";
import AccountService from "./payment/payment";
import ContentService from "./content/content";
import UserService from "./users/users";

const AuthApi = new AuthService();
const SubjectApi = new SubjectService();
const AccountApi = new AccountService();
const ContentApi = new ContentService();
const UserApi = new UserService();

export { AuthApi, SubjectApi, AccountApi, ContentApi, UserApi }