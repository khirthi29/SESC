import licvifyService from "../axios/axios";

class AccountService {

    getAccounts(data) {
        return Promise.resolve(licvifyService.post('getaccountsli', data));
    }

    rechargeAmount(data) {
        return Promise.resolve(licvifyService.post('rechargeamtli', data));
    }
}

export default AccountService;