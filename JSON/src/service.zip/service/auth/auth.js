import licvifyService from "../axios/axios";

class AuthService {

    generateOTP(data) {
        return Promise.resolve(licvifyService.post('genotpli', data));
    }

    signIn(data) {
        return Promise.resolve(licvifyService.post('signinli', data));
    }

    register(data) {
        return Promise.resolve(licvifyService.post('setregistrationli', data));
    }
    
    gstValidate(data) {
        return Promise.resolve(licvifyService.post('getgstvalidateli', data));
    }

    getRegistrationList(data) {
        return Promise.resolve(licvifyService.post('regrevlistli', data));
    }

    setRegistrationVerdict(data) {
        return Promise.resolve(licvifyService.post('regverdictli', data));
    }
    
}

export default AuthService;