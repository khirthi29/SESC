import licvifyService from "../axios/axios";

class ContentService {

    addContent(data) {
        return Promise.resolve(licvifyService.post('addcontentli', data));
    }

    editContent(data) {
        return Promise.resolve(licvifyService.post('editcontentli', data));
    }

    getAnswer(data) {
        return Promise.resolve(licvifyService.post('getanswerli', data));
    }

    getFeedback(data) {
        return Promise.resolve(licvifyService.post('getfeedbackli', data));
    }
}
export default ContentService;